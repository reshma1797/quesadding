package com.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.model.ExamModify;
import com.service.AuthService;
import com.service.ExamModifyService;
import com.service.ExamModifyServiceImpl;
import com.service.QuesAddingService;

@Component
@Controller
@RequestMapping("/ExamModification")
public class ExamDetailsCtrl {
	
	@Autowired
	private AuthService authenticateService; 

	

	public ExamDetailsCtrl() {
		System.out.println("ExamDetailsCtrl()");
	}

	@Autowired
	private ExamModifyService examModifyService;
	
	@Autowired
	private QuesAddingService quesAddingService;
	

	@RequestMapping(value = "/ExamHome")
	public ModelAndView listExamModify(ModelAndView model) throws IOException {
		System.out.println("Inside / of controller...");
		
		List<ExamModify> listExamModify = authenticateService.getAllExamModify();
		
		
		for (ExamModify e : listExamModify)
		{
			System.out.println(e.getId());
		}
		model.addObject("listExamModify", listExamModify);
		model.setViewName("adminHome");
		return model;
	}


	@RequestMapping(value = "", method = RequestMethod.GET)
	public ModelAndView showAdmin(ModelAndView model) {
		model.setViewName("adminHome");
		return model;
	}
	@RequestMapping(value = "/newExamModify", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		ExamModify exam = new ExamModify();
		model.addObject("exam", exam);
		model.setViewName("ExamModifyForm");
		return model;
	}

	@RequestMapping(value = "/saveExamModify", method = RequestMethod.POST)
	public ModelAndView saveExamModify(@ModelAttribute ExamModify exam) {
		if (exam.getId() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			authenticateService.addExamModify(exam);
		} else {
			authenticateService.updateExamModify(exam);
		}
		return new ModelAndView("redirect:/ExamModification/ExamHome");
	}
	@RequestMapping (value="/SaveEditExam", method=RequestMethod.GET)
	public ModelAndView SaveEdit(@ModelAttribute ExamModify exam)
	{
		System.out.println("Inside /SaveEdit...");
		return new ModelAndView("redirect:/ExamModification/ExamHome");
	}
	@RequestMapping(value = "/deleteExamModify", method = RequestMethod.GET)
	public ModelAndView deleteExamModify(HttpServletRequest request) {
		System.out.println("Inside /deleteExamModify...");
	//	int id = Integer.parseInt(request.getParameter("id"));
	 
	//	authenticateService.deleteExamModify(id);
		return new ModelAndView("redirect:/ExamModification/ExamHome");
	}

	@RequestMapping(value = "/editExamModify", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		
		//ExamModify exam = authenticateService.getExamModify(id);
		ModelAndView model = new ModelAndView("ExamModifyForm");
		//model.addObject("exam", exam);

		return model;
	}
	@ModelAttribute("levelList")
	public Map<String, String> getLevelList() {
		Map<String, String> levelList = new HashMap<String, String>();
		levelList.put("Easy", "LEVEL-1");
		levelList.put("Medium", "LEVEL-2");
		levelList.put("Hard", "LEVEL-3");

		return levelList;
	}
	


}