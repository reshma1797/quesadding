
package com.service;

import java.util.List;


import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.model.User;
import com.model.ExamModify;
import com.model.QuesAdding;
 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
   
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked" } )
    public String findUser(String userId, String upwd) {
   
        String returnType = new String("Invalid");
        
        String sqlQuery = "from User where user_id=? and password=?";
      
        System.out.println("In the authentication service...user entered data " + userId + " pwd "+upwd);
        
        String emp_type=new String("");
        try {
            List<User> userObj = (List<User>) hibernateTemplate.find(sqlQuery, userId, upwd);
            System.out.println("User : "+userObj);
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (User obj : userObj)
                {
                     System.out.println("Id "+obj.getUserId());
                    emp_type = obj.getEmpType();
                    returnType = emp_type;
                }

            }          
            
            
            if(userObj != null && userObj.size() > 0) {
                //log.info("Id= " + userObj.get(0)).getId() + ", Name= " + userObj.get(0).getName() + ", Password= " + userObj.get(0).getPassword());
            	return returnType;
            	
            }
        } catch(Exception e) {
        	 System.out.println("Exception : "+e);
        	returnType = "Invalid";
                 
        }
        return returnType;
    }
 
  
	public boolean registeruser(User reg) {
		// TODO Auto-generated method stub
		System.out.println("Before database");
		System.out.println("reg data :"+reg.getFirstName());
     Session session = hibernateTemplate.getSessionFactory().openSession();
       session.save(reg);
		//hibernateTemplate.save(reg);
		System.out.println("After database");
		return true;
	}
	
	
	public List<QuesAdding> getAllQuesAdding() {
		
		System.out.println("In getAllQuesAdding...");
		//System.out.println("Session data "+sessionFactory.getCurrentSession());
		//List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
		String sqlQuery = new String("from QuesAdding");
		System.out.println("HibernateTemplate "+hibernateTemplate);
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery);
        
        if(userObjLst != null)
        {
        	System.out.println("userObject is not null... ");
        }   
				
        return userObjLst;
	} 
	
	
	 
	public void addQuesAdding(QuesAdding ques) {
		     	
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "INSERT INTO Question (question,choice_1,choice_2,choice_3,choice_4,selection,skill_set,competency_level,mark,answer) VALUES  (?,?,?,?,?,?,?,?,?,?)";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		
		insertQuery.setParameter(0,ques.getQuestion());
		insertQuery.setParameter(1,ques.getA());
		insertQuery.setParameter(2,ques.getB());
		insertQuery.setParameter(3,ques.getC());
		insertQuery.setParameter(4,ques.getD());
		insertQuery.setParameter(5,ques.getSelection());
		insertQuery.setParameter(6,ques.getSkill());
		insertQuery.setParameter(7,ques.getLevel());
		insertQuery.setParameter(8,ques.getAnswer());
		insertQuery.setParameter(9, ques.getMark());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
	}
	
	public void deleteQuesAdding(Integer id) {
		 
		hibernateTemplate.bulkUpdate("DELETE FROM QuesAdding where qId ="+id);
		  
 	}
	
	public QuesAdding getQuesAdding(int id) {
		String sqlQuery = new String("from QuesAdding where qId = ?");
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery,id);
		
		QuesAdding QuesObj=null;
		for (QuesAdding QuesObj1 : userObjLst)
		{
			  QuesObj = QuesObj1;
		}
		return QuesObj;

		//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
	}
	
	public QuesAdding updateQuesAdding(QuesAdding ques) {
		//sessionFactory.getCurrentSession().update(ques);
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "update Question SET choice_1 =?,choice_2=?,choice_3=?,choice_4=?,mark=?,question=?,selection=?,skill_set=?,answer=?,competency_level=? WHERE question_id=?";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		insertQuery.setParameter(0, ques.getA());
		
		insertQuery.setParameter(1,ques.getB());
		insertQuery.setParameter(2,ques.getC());
		insertQuery.setParameter(3,ques.getD());
		insertQuery.setParameter(4,ques.getMark());
		insertQuery.setParameter(5,ques.getQuestion());
		insertQuery.setParameter(6,ques.getSelection());
		insertQuery.setParameter(7,ques.getSkill());
		insertQuery.setParameter(8,ques.getAnswer());
		insertQuery.setParameter(9,ques.getLevel());
		insertQuery.setParameter(10,ques.getqId());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
		 
		
		return ques;
	}

//hibernateTemplate.save(ques, ques.getId(),ques.getMark(),ques.getQuestion(),ques.getA(),ques.getB(),ques.getC(),ques.getD(),ques.getSelection(),ques.getSkill(),ques.getAnswer(),ques.getLevel() );
public List<ExamModify> getAllExamModify() {
	
	System.out.println("In getAllExamModify...");
	//System.out.println("Session data "+sessionFactory.getCurrentSession());
	//List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
	String sqlQuery = new String("from ExamModify");
	System.out.println("HibernateTemplate "+hibernateTemplate);
	@SuppressWarnings("unchecked")
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery);
    
    if(userObjLst != null)
    {
    	System.out.println("userObject is not null... ");
    }   
			
    return userObjLst;
} 


 
public void addExamModify(ExamModify exam) {
	
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "INSERT INTO exam (exam_id,exam_description,skill_set,competency_level) VALUES  (?,?,?,?)";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	 
	insertQuery.setParameter(0, exam.geteId());
	insertQuery.setParameter(1, exam.getExam_name());
	insertQuery.setParameter(2,exam.getSkill());
	insertQuery.setParameter(3,exam.getLevel());
	insertQuery.executeUpdate();
	 
	session.getTransaction().commit();
}

public void deleteExamModify(String id) {
	 
	hibernateTemplate.bulkUpdate("DELETE FROM ExamModify where eId ='"+id+"'");
	  
	}

public ExamModify getExamModify(String id) {
	String sqlQuery = new String("from ExamModify where eId = ?");
	@SuppressWarnings("unchecked")
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery,id);
	
	ExamModify ExamObj=null;
	for (ExamModify ExamObj1 : userObjLst)
	{
		  ExamObj = ExamObj1;
	}
	return ExamObj;

	//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
}

public ExamModify updateExamModify(ExamModify exam) {
	//sessionFactory.getCurrentSession().update(ques);
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "update exam SET exam_description=?,skill_set=?,competency_level=? WHERE exam_id=?";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	;
	insertQuery.setParameter(0,exam.getExam_name());
	insertQuery.setParameter(1,exam.getSkill());
	
	insertQuery.setParameter(2,exam.getLevel());
	insertQuery.setParameter(3,exam.geteId());
	 
	 insertQuery.executeUpdate();
	 session.getTransaction().commit();
	 
	
	return exam;
}
}
