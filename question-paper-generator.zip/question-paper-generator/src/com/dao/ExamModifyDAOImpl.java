package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.ExamModify;


@Repository
@Transactional(readOnly = false)
public class ExamModifyDAOImpl implements ExamModifyDAO{
	
	private HibernateTemplate hibernateTemplate;

	public void addExamModify(ExamModify exam) {
		//sessionFactory.getCurrentSession().saveOrUpdate(exam);
		hibernateTemplate.save(exam);

	}

	@Transactional(readOnly = false)
	public List<ExamModify> getAllExamModify() {
		
		System.out.println("In getAllExamModify...");
		//System.out.println("Session data "+sessionFactory.getCurrentSession());
		//List <ExamModify> lst = (sessionFactory.getCurrentSession().createQuery("from ExamModify")).list();
				
		String sqlQuery = new String("from ExamModify");
		System.out.println("HibernateTemplate "+hibernateTemplate);
		
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Session object is "+session);
		List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery);
        
        if(userObjLst != null)
        {
        	System.out.println("userObject is not null... ");
        }   
				
        return userObjLst;
	} 
	@Transactional(readOnly = false)

	public void deleteExamModify(Integer id) {
		hibernateTemplate.bulkUpdate("DELETE FROM ExamModify where id ="+id);

	}

	public ExamModify getExamModify(int id) {
		String sqlQuery = new String("from ExamModify where id = ?");
		@SuppressWarnings("unchecked")
		List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery,id);
		
		ExamModify ExamObj=null;
		for (ExamModify ExamObj1 : userObjLst)
		{
			  ExamObj = ExamObj1;
		}
		return ExamObj;
	}

	public ExamModify updateExamModify(ExamModify exam) {
System.out.println("In Update...updateExamModify()");
		
		String sqlQuery = new String("UPDATE ExamModify SET ");
		hibernateTemplate.saveOrUpdate(exam);
		
		return exam;
	}
	}
	
	


