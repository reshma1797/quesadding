package com.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.model.ExamModify;

import com.service.ExamModifyService;
import com.service.ExamModifyServiceImpl;

@Component
@Controller
public class ExamDetailsCtrl {

	private static final Logger logger = Logger
			.getLogger(ExamDetailsCtrl.class);

	public ExamDetailsCtrl() {
		System.out.println("ExamDetailsCtrl()");
	}

	@Autowired
	private ExamModifyService examModifyService;

	@RequestMapping(value = "/")
	public ModelAndView listExamModify1(ModelAndView model) throws IOException {
		System.out.println("Inside / of controller...");
		
		List<ExamModify> listExamModify = examModifyService.getAllEmployees();
		
		
		for (ExamModify e : listExamModify)
		{
			System.out.println(e.getId());
		}
		model.addObject("listExamModify", listExamModify);
		model.setViewName("examDetails");
		return model;
	}

	@RequestMapping(value = "/newExamModify", method = RequestMethod.GET)
	public ModelAndView newContact1(ModelAndView model) {
		ExamModify exam = new ExamModify();
		model.addObject("exam", exam);
		model.setViewName("ExamModifyForm");
		return model;
	}

	@RequestMapping(value = "/saveExamModify", method = RequestMethod.POST)
	public ModelAndView saveExamModify(@ModelAttribute ExamModify exam) {
		if (exam.getId() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			examModifyService.addExamModify(exam);
		} else {
			examModifyService.updateExamModify(exam);
		}
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteExamModify", method = RequestMethod.GET)
	public ModelAndView deleteExamModify1(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
	 
		examModifyService.deleteExamModify(id);
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editExamModify", method = RequestMethod.GET)
	public ModelAndView editContact1(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		
		ExamModify exam = examModifyService.getExamModify(id);
		ModelAndView model = new ModelAndView("ExamModifyForm");
		model.addObject("exam", exam);

		return model;
	}

}