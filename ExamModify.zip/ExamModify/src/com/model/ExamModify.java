package com.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Exam")

public class ExamModify implements Serializable {
	
	private static final long serialVersionUID = -3465813074586302847L;

	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column
	private String exam_name;

	@Column
	private String skill_set;

	@Column
	private String competency_level;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getExam_name() {
		return exam_name;
	}

	public void setExam_name(String exam_name) {
		this.exam_name = exam_name;
	}

	public String getSkill_set() {
		return skill_set;
	}

	public void setSkill_set(String skill_set) {
		this.skill_set = skill_set;
	}

	public String getCompetency_level() {
		return competency_level;
	}

	public void setCompetency_level(String competency_level) {
		this.competency_level = competency_level;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

}
