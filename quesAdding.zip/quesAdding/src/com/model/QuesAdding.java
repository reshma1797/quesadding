
package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Question")

public class QuesAdding implements Serializable {
     
    /*@Override
     public String toString() {
          return "[qId=" + qId + ", mark=" + mark + ", question=" + question + ", a=" + a + ", b=" + b + ", c="
                   + c + ", d=" + d + ", selection=" + selection + ", skill=" + skill + ", level=" + level + ", answer="
                   + answer + "]";
     }*/
     private static final long serialVersionUID = 1L;
    
    //required attribute for question 
     @Id	
 	@GeneratedValue(strategy = GenerationType.AUTO)
     private int id;

     public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

     @Column
      private int mark;
     @Column
      private String question;
     @Column
      private String  a;
     @Column
      private String b;
     @Column
      private String c;
     @Column
      private String d;
     @Column
      private String selection;
     @Column
      private String skill;
     @Column
      private String level;
     @Column
      private String answer;
     
     //setter and getter method for attribute 
    
     public int getMark() {
          return mark;
     }
     public void setMark(int mark) {
          this.mark = mark;
     }
     public String getQuestion() {
          return question;
     }
     public void setQuestion(String question) {
          this.question = question;
     }
     public String getA() {
          return a;
     }
     public void setA(String a) {
          this.a = a;
     }
     public String getB() {
          return b;
     }
     public void setB(String b) {
          this.b = b;
     }
     public String getC() {
          return c;
     }
     public void setC(String c) {
          this.c = c;
     }
     public String getD() {
          return d;
     }
     public void setD(String d) {
          this.d = d;
     }
     public String getSelection() {
          return selection;
     }
     public void setSelection(String selection) {
          this.selection = selection;
     }
     public String getSkill() {
          return skill;
     }
     public void setSkill(String skill) {
          this.skill = skill;
     }
     public String getLevel() {
          return level;
     }
     public void setLevel(String level) {
          this.level = level;
     }
     public String getAnswer() {
          return answer;
     }
     public void setAnswer(String answer) {
          this.answer = answer;
     }

     

}

