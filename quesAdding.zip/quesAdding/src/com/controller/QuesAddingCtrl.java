package com.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.ExamModify;
import com.model.QuesAdding;
import com.service.ExamModifyService;
import com.service.QuesAddingService;
import com.service.QuesAddingServiceImpl;

@Component
@Controller
public class QuesAddingCtrl {

	private static final Logger logger = Logger
			.getLogger(QuesAddingCtrl.class);

	public QuesAddingCtrl() {
		System.out.println("QuesAddingCtrl()");
	}

	@Autowired
	private QuesAddingService quesAddingService;
	@Autowired
	private ExamModifyService examModifyService;
	@RequestMapping(value = "/")
	public ModelAndView listQuesAdding(ModelAndView model) throws IOException {
		System.out.println("Inside / of controller...");
		
		List<QuesAdding> listQuesAdding = quesAddingService.getAllEmployees();
		
		
		for (QuesAdding e : listQuesAdding)
		{
			System.out.println(e.getId());
		}
		model.addObject("listQuesAdding", listQuesAdding);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newQuesAdding", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		QuesAdding ques = new QuesAdding();
		model.addObject("ques", ques);
		model.setViewName("QuesAddingForm");
		return model;
	}

	@RequestMapping(value = "/saveQuesAdding", method = RequestMethod.POST)
	public ModelAndView saveQuesAdding(@ModelAttribute QuesAdding ques) {
		if (ques.getId() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			quesAddingService.addQuesAdding(ques);
		} else {
			quesAddingService.updateQuesAdding(ques);
		}
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteQuesAdding", method = RequestMethod.GET)
	public ModelAndView deleteQuesAdding(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
	 
		quesAddingService.deleteQuesAdding(id);
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editQuesAdding", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		
		QuesAdding ques = quesAddingService.getQuesAdding(id);
		ModelAndView model = new ModelAndView("QuesAddingForm");
		model.addObject("ques", ques);

		return model;
	}
	 @ModelAttribute("levelList")
	   public Map<String, String> getLevelList() {
	      Map<String, String> levelList = new HashMap<String, String>();
	      levelList.put("Easy", "LEVEL-1");
	      levelList.put("Medium", "LEVEL-2");
	      levelList.put("Hard", "LEVEL-3");
	      
	      return levelList;
	   }
	 
	 //-----------------------------------------------------------------------
	
		/*@RequestMapping(value = "/")
		public ModelAndView listExamModify(ModelAndView model) throws IOException {
			System.out.println("Inside / of controller...");
			
			List<ExamModify> listExamModify = examModifyService.getAllEmployees();
			
			
			for (ExamModify e : listExamModify)
			{
				System.out.println(e.getId());
			}
			model.addObject("listExamModify", listExamModify);
			model.setViewName("examDetails");
			return model;
		}
*/
		@RequestMapping(value = "/newExamModify", method = RequestMethod.GET)
		public ModelAndView newContact1(ModelAndView model) {
			ExamModify exam = new ExamModify();
			model.addObject("exam", exam);
			model.setViewName("ExamModifyForm");
			return model;
		}

		@RequestMapping(value = "/saveExamModify", method = RequestMethod.POST)
		public ModelAndView saveExamModify(@ModelAttribute ExamModify exam) {
			if (exam.getId() == 0) { // if employee id is 0 then creating the
				// employee other updating the employee
				examModifyService.addExamModify(exam);
			} else {
				examModifyService.updateExamModify(exam);
			}
			return new ModelAndView("redirect:/");
		}

		@RequestMapping(value = "/deleteExamModify", method = RequestMethod.GET)
		public ModelAndView deleteExamModify(HttpServletRequest request) {
			int id = Integer.parseInt(request.getParameter("id"));
		 
			examModifyService.deleteExamModify(id);
			return new ModelAndView("redirect:/");
		}

		@RequestMapping(value = "/editExamModify", method = RequestMethod.GET)
		public ModelAndView editContact1(HttpServletRequest request) {
			int id = Integer.parseInt(request.getParameter("id"));
			
			ExamModify exam = examModifyService.getExamModify(id);
			ModelAndView model = new ModelAndView("ExamModifyForm");
			model.addObject("exam", exam);

			return model;
		}

}
