package com.service;

/*import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.ExamModifyDAO;
import com.model.ExamModify;

@Service
@Transactional

public class ExamModifyServiceImpl {

	@Autowired
	private ExamModifyDAO examModifyDAO;

	@Transactional
	public void addExamModify(ExamModify exam) {
		examModifyDAO.addExamModify(exam);
	}

	@Transactional
	public List<ExamModify> getAllExamModify() {
		System.out.println("Inside ExamModifyServiceImpl..getAllExamModify() ");
		return examModifyDAO.getAllExamModify();
	}

	@Transactional
	public void deleteExamModify(Integer exam_id) {
		examModifyDAO.deleteExamModify(exam_id);
	}

	public ExamModify getExamModify(int exam_id) {
		return examModifyDAO.getExamModify(exam_id);
	}

	public ExamModify updateExamModify(ExamModify exam) {
		// TODO Auto-generated method stub
		return examModifyDAO.updateExamModify(exam);
	}

	public void setExamModifyDAO(ExamModifyDAO examModifyDAO) {
		this.examModifyDAO = examModifyDAO;
	}

}
*/



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.ExamModifyDAO;
import com.model.ExamModify;

@Service
@Transactional
public class ExamModifyServiceImpl implements ExamModifyService {

	@Autowired
	private ExamModifyDAO employeeDAO;

	@Transactional
	public void addExamModify(ExamModify employee) {
		employeeDAO.addExamModify(employee);
	}

	@Transactional
	public List<ExamModify> getAllEmployees() {
		return employeeDAO.getAllExamModify();
	}

	@Transactional
	public void deleteExamModify(Integer employeeId) {
		employeeDAO.deleteExamModify(employeeId);
	}

	public ExamModify getExamModify(int empid) {
		return employeeDAO.getExamModify(empid);
	}

	public ExamModify updateExamModify(ExamModify employee) {
		// TODO Auto-generated method stub
		return employeeDAO.updateExamModify(employee);
	}

	public void setExamModifyDAO(ExamModifyDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

}
