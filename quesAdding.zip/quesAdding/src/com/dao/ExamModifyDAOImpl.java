package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.ExamModify;

@Repository
public class ExamModifyDAOImpl implements ExamModifyDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void addExamModify(ExamModify exam) {
		sessionFactory.getCurrentSession().saveOrUpdate(exam);

	}

	@SuppressWarnings("unchecked")
	public List<ExamModify> getAllExamModify() {
		
		System.out.println("In getAllEmployees...");
		System.out.println("Session data "+sessionFactory.getCurrentSession());
		List <ExamModify> lst = (sessionFactory.getCurrentSession().createQuery("from ExamModify")).list();
				
        return lst;
	} 

	public void deleteExamModify(Integer id) {
		ExamModify exam = (ExamModify) sessionFactory.getCurrentSession().load(
				ExamModify.class, id);
		if (null != exam) {
			this.sessionFactory.getCurrentSession().delete(exam);
		}

	}

	public ExamModify getExamModify(int id) {
		return (ExamModify) sessionFactory.getCurrentSession().get(
				ExamModify.class,id);
	}

	public ExamModify updateExamModify(ExamModify exam) {
		sessionFactory.getCurrentSession().update(exam);
		return exam;
	}
	
	

}
