
package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.QuesAdding;

@Repository
public class QuesAddingDAOImpl implements QuesAddingDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void addQuesAdding(QuesAdding ques) {
		sessionFactory.getCurrentSession().saveOrUpdate(ques);

	}

	@SuppressWarnings("unchecked")
	public List<QuesAdding> getAllQuesAdding() {
		
		System.out.println("In getAllEmployees...");
		System.out.println("Session data "+sessionFactory.getCurrentSession());
		List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
				
        return lst;
	} 

	public void deleteQuesAdding(Integer id) {
		QuesAdding ques = (QuesAdding) sessionFactory.getCurrentSession().load(
				QuesAdding.class, id);
		if (null != ques) {
			this.sessionFactory.getCurrentSession().delete(ques);
		}

	}

	public QuesAdding getQuesAdding(int id) {
		return (QuesAdding) sessionFactory.getCurrentSession().get(
				QuesAdding.class,id);
	}

	public QuesAdding updateQuesAdding(QuesAdding ques) {
		sessionFactory.getCurrentSession().update(ques);
		return ques;
	}
	
	

}

